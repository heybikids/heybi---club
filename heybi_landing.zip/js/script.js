// Link Configuration
const LINKS = {
  shopee: "https://shopee.co.id/USERNAME",
  whatsapp: "https://wa.me/628xxxxxxxxxx",
  instagram: "https://instagram.com/USERNAME",
  tiktok: "https://tiktok.com/@USERNAME",
  tokopedia: "https://tokopedia.com/USERNAME",
  website: "https://USERNAME.github.io/heybi"
};

document.addEventListener('DOMContentLoaded', () => {
    // Set Links
    document.getElementById('btn-shopee-hero').href = LINKS.shopee;
    document.getElementById('link-shopee').href = LINKS.shopee;
    document.getElementById('link-whatsapp').href = LINKS.whatsapp;
    document.getElementById('link-instagram').href = LINKS.instagram;
    document.getElementById('link-tiktok').href = LINKS.tiktok;
    document.getElementById('link-tokopedia').href = LINKS.tokopedia;
    document.getElementById('link-website').href = LINKS.website;

    // Loading Animation
    window.addEventListener('load', () => {
        document.getElementById('loader').style.display = 'none';
    });

    // Ripple Effect
    const cards = document.querySelectorAll('.link-card');
    cards.forEach(card => {
        card.addEventListener('click', function(e) {
            let x = e.clientX - e.target.offsetLeft;
            let y = e.clientY - e.target.offsetTop;
            let ripple = document.createElement('span');
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            this.appendChild(ripple);
            setTimeout(() => ripple.remove(), 600);
        });
    });
});
